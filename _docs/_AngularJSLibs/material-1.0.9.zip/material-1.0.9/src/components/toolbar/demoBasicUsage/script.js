
angular.module('toolbarDemo1', ['ngMaterial'])

.controller('AppCtrl', function($scope) {

});
